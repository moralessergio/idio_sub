<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', '9YLpmnc2Ex8Ebo5D4lIJdA');
define('CONSUMER_SECRET', 'Pt6r8BScpHCsNsEUsez3bmBXHOdxOOy4n9L33dA6uTU');
define('OAUTH_CALLBACK', 'http://serch.me/demos/idio/twitteroauth-master/callback.php');
